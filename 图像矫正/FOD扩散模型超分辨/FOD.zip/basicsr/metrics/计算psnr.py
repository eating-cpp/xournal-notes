import os
import cv2
import numpy as np
from copy import deepcopy
import os
import cv2
from basicsr.utils.registry import METRIC_REGISTRY
# from niqe import calculate_niqe
from psnr_ssim import calculate_psnr, calculate_ssim, calculate_ssim_pt, calculate_psnr_pt

# 假设 calculate_psnr 函数已定义
# from psnr_module import calculate_psnr

def calculate_folder_psnr(folder_path, ref_folder_path, crop_border=4, input_order='HWC', test_y_channel=True):
    psnr_scores = []

    # 遍历文件夹中的所有图像文件
    for filename in os.listdir(folder_path):
        if filename.endswith('.png') or filename.endswith('.jpg'):
            img_path = os.path.join(folder_path, filename)
            ref_img_path = os.path.join(ref_folder_path, filename)

            # 读取图像和参考图像
            img = cv2.imread(img_path)
            ref_img = cv2.imread(ref_img_path)
            if img is None or ref_img is None:
                print(f"Warning: Failed to read {img_path} or {ref_img_path}")
                continue

            # 计算 PSNR
            psnr_score = calculate_psnr(img, ref_img, crop_border, input_order, test_y_channel)
            psnr_scores.append(psnr_score)

            print(f"Image: {filename}, PSNR Score: {psnr_score}")

    # 计算 PSNR 平均分
    if psnr_scores:
        average_psnr = sum(psnr_scores) / len(psnr_scores)
        print(f"Average PSNR Score: {average_psnr}")
        return psnr_scores, average_psnr
    else:
        print("No images found for PSNR calculation.")
        return psnr_scores, None


# 指定图像文件夹和参考图像文件夹路径
folder_path = r'C:\Users\ShbWang\Desktop\pasd\ori_d2'
ref_folder_path = r'D:\pytorch-w\dataset\StableSR_testsets\DrealSRVal_crop128\test_HR'
psnr_scores, average_psnr = calculate_folder_psnr(folder_path, ref_folder_path)

# 输出所有图像的 PSNR 分数以及平均分
if psnr_scores:
    print("\nIndividual PSNR Scores:")
    print(f"\nAverage PSNR Score for the folder: {average_psnr}")
