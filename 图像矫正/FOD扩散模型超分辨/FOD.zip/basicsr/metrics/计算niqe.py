from copy import deepcopy
import os
import cv2
from basicsr.utils.registry import METRIC_REGISTRY
from niqe import calculate_niqe
from psnr_ssim import calculate_psnr, calculate_ssim, calculate_ssim_pt, calculate_psnr_pt





import os
import cv2
import numpy as np


# 假设 calculate_niqe 函数已定义
# from niqe_module import calculate_niqe

def calculate_folder_niqe(folder_path, crop_border=4, input_order='HWC', convert_to='y'):
    niqe_scores = []

    # 遍历文件夹中的所有图像文件
    for filename in os.listdir(folder_path):
        if filename.endswith('.png') or filename.endswith('.jpg'):
            file_path = os.path.join(folder_path, filename)

            # 读取图像
            img = cv2.imread(file_path)
            if img is None:
                print(f"Warning: Failed to read {file_path}")
                continue

            # 计算 NIQE
            niqe_score = calculate_niqe(img, crop_border, input_order, convert_to)
            niqe_scores.append(niqe_score)

            print(f"Image: {filename}, NIQE Score: {niqe_score}")

    # 计算 NIQE 平均分
    if niqe_scores:
        average_niqe = sum(niqe_scores) / len(niqe_scores)
        print(f"Average NIQE Score: {average_niqe}")
        return niqe_scores, average_niqe
    else:
        print("No images found for NIQE calculation.")
        return niqe_scores, None


# 指定图像文件夹路径
folder_path = r'C:\Users\ShbWang\Desktop\sample00\memory_attn_stage2\sample00'
niqe_scores, average_niqe = calculate_folder_niqe(folder_path)

# 输出所有图像的 NIQE 分数以及平均分

print("\nIndividual NIQE Scores:")
print(f"\nAverage NIQE Score for the folder: {average_niqe}")

