import torch.nn.functional as F
from torch.autograd import Variable
import torch
import torch.nn as nn

class CvBlock(nn.Module):
    '''(Conv2d => BN => ReLU) x 2'''

    def __init__(self, in_ch, out_ch):
        super(CvBlock, self).__init__()
        self.convblock = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, kernel_size=3, padding=1, bias=False),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.convblock(x)




class DownBlock(nn.Module):
    '''Downscale + (Conv2d => BN => ReLU)*2'''

    def __init__(self, in_ch, out_ch):
        super(DownBlock, self).__init__()
        self.convblock = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=3,
                      padding=1, stride=2, bias=False),
            nn.ReLU(inplace=True),
            CvBlock(out_ch, out_ch)
        )

    def forward(self, x):
        return self.convblock(x)


class UpBlock(nn.Module):
    '''(Conv2d => BN => ReLU)*2 + Upscale'''

    def __init__(self, in_ch, out_ch):
        super(UpBlock, self).__init__()
        self.convblock = nn.Sequential(
            CvBlock(in_ch, in_ch),
            nn.Conv2d(in_ch, out_ch*4, kernel_size=3, padding=1, bias=False),
            nn.PixelShuffle(2)
        )

    def forward(self, x):
        return self.convblock(x)


class OutputCvBlock(nn.Module):
    '''Conv2d => BN => ReLU => Conv2d'''

    def __init__(self, in_ch, out_ch):
        super(OutputCvBlock, self).__init__()
        self.convblock = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=False)
        )

    def forward(self, x):
        return self.convblock(x)


class DenBlock(nn.Module):
    """ Definition of the denosing block of FastDVDnet.
    Inputs of constructor:
            num_input_frames: int. number of input frames
    Inputs of forward():
            xn: input frames of dim [N, C, H, W], (C=3 RGB)
            noise_map: array with noise map of dim [N, 1, H, W]
    """

    def __init__(self, num_input_frames=1, in_chans=3,chs_lyr0=32, chs_lyr1=64, chs_lyr2=128):
        super(DenBlock, self).__init__()
        self.chs_lyr0 = chs_lyr0
        self.chs_lyr1 = chs_lyr1
        self.chs_lyr2 = chs_lyr2

        self.inc = nn.Conv2d(in_chans,chs_lyr0,3,1,1)

        self.downc0 = DownBlock(in_ch=self.chs_lyr0, out_ch=self.chs_lyr1)
        self.downc1 = DownBlock(in_ch=self.chs_lyr1, out_ch=self.chs_lyr2)
        self.upc2 = UpBlock(in_ch=self.chs_lyr2, out_ch=self.chs_lyr1)
        self.upc1 = UpBlock(in_ch=self.chs_lyr1, out_ch=self.chs_lyr0)
        self.outc = OutputCvBlock(in_ch=self.chs_lyr0, out_ch=in_chans)

    def forward(self, in0):
        '''Args:
                inX: Tensor, [N, C, H, W] in the [0., 1.] range
                noise_map: Tensor [N, 1, H, W] in the [0., 1.] range
        '''
        # Input convolution block
        x0 = self.inc(in0)
        # Downsampling
        x1 = self.downc0(x0)
        x2 = self.downc1(x1)
        # Upsampling
        x2 = self.upc2(x2)
        x1 = self.upc1(x1+x2)
        # Estimation
        x = self.outc(x0+x1)

        # Residual
        x = in0 - x

        return x


class Alin_net(nn.Module):
    """ Definition of the model.
    Inputs of forward():
            xn: input frames of dim [N, C, H, W], (C=3 RGB)
            noise_map: array with noise map of dim [N, 1, H, W]
    """

    def __init__(self, num_input_frames=1,in_chans=3,embed_dim = 32):
        super(Alin_net, self).__init__()
        self.num_input_frames = num_input_frames
        # Define models of each denoising stage
        self.temp1 = DenBlock(num_input_frames=1,in_chans=in_chans,chs_lyr0=embed_dim)
        # self.temp2 = DenBlock(num_input_frames=1,in_chans=in_chans,chs_lyr0=embed_dim)

    def forward(self, x):


        # First stage
        x1 = self.temp1(x)

        # Second stage
        # x2 = self.temp2(x1)

        return x1

if __name__ == '__main__':
    import os
    # os.environ['CUDA_VISIBLE_DEVICES'] = '4'
    net = Alin_net().cuda()
    # print(net)
    x = Variable(torch.FloatTensor(1, 3, 320, 180)).cuda()
    y = net(x)
    print(y[0].shape)
    num_params = 0
    for param in net.parameters():
        num_params += param.numel()
    print('Total number of parameters: %d' % num_params)


    from thop import profile
    flops, params = profile(net, inputs=(x,))
    print("%.6f GFLOPs." % (flops / 1e9))
    print("%.6f Params(M)." % (params / 1e6))
